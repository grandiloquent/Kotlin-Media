package euphoria.psycho.media.fragments

import androidx.fragment.app.Fragment
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils

/**
 * A simple [Fragment] subclass.
 */
abstract class BaseFragment : Fragment() {
    companion object {

        val FILE_TYPE = "FILE_TYPE"
    }
}// Required empty public constructor
