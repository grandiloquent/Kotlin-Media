package euphoria.psycho.common.ui;

public interface OrientationSource {
    public int getDisplayRotation();
    public int getCompensation();
}
