package euphoria.psycho.common.ui;


import euphoria.psycho.common.glrenderer.GLCanvas;

public abstract class CanvasAnimation extends Animation {

    public abstract int getCanvasSaveFlags();
    public abstract void apply(GLCanvas canvas);
}
