package euphoria.psycho.media.adapters

interface Selectable<T> {
    val selectedItemCount: Int
    fun isSelected(item: T): Boolean
    fun toggleSelection(item: T)
    fun clearSelection()
}