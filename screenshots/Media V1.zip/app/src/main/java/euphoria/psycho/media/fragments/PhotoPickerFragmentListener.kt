package euphoria.psycho.media.fragments

interface PhotoPickerFragmentListener {
    fun onItemSelected()
}