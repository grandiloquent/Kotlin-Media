package euphoria.psycho.media.cursors.loadercallbacks


import euphoria.psycho.media.models.Document
import euphoria.psycho.media.models.FileType

/**
 * Created by gabriel on 10/2/17.
 */

interface FileMapResultCallback {
    fun onResultCallback(files: Map<FileType, List<Document>>)
}

