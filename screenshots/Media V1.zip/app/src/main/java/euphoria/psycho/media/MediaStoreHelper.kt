package euphoria.psycho.media

import android.content.ContentResolver
import android.os.Bundle
import euphoria.psycho.media.cursors.DocScannerTask

import java.util.Comparator


import euphoria.psycho.media.cursors.PhotoScannerTask
import euphoria.psycho.media.cursors.loadercallbacks.FileMapResultCallback
import euphoria.psycho.media.cursors.loadercallbacks.FileResultCallback
import euphoria.psycho.media.models.Document
import euphoria.psycho.media.models.FileType
import euphoria.psycho.media.models.PhotoDirectory

object MediaStoreHelper {

    fun getDirs(contentResolver: ContentResolver, args: Bundle, resultCallback: FileResultCallback<PhotoDirectory>) {
        PhotoScannerTask(contentResolver,args,resultCallback).execute()
    }

    fun getDocs(contentResolver: ContentResolver,
                fileTypes: List<FileType>,
                comparator: Comparator<Document>,
                fileResultCallback: FileMapResultCallback
    ) {
        DocScannerTask(contentResolver, fileTypes, comparator, fileResultCallback).execute()
    }
}