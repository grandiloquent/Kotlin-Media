package euphoria.psycho.media

interface BrowserItemListener {
    fun onClicked(browserItem: BrowserItem)
    fun onCameraClicked()

}