package euphoria.psycho.media

data class BrowserItem(
    var path: String,
    var size: Long
)